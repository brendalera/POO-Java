package ar.edu.unahur.po2.Parcial;

public interface Persona {
	
}
